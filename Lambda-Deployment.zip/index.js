'use strict';


var AWS = require('aws-sdk');


exports.handler = function(event, context, callback){
    console.log('Welcome to AWS Lambda.');
};
