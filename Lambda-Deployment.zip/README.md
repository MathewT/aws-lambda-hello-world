# AWS Lambda Notes:

## Node.js Setup on Ubuntu
